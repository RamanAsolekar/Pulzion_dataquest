"""Build-time download of the two ONNX models (pinned revisions, verified sizes).

Files land in $HF_HOME/models/<name>/ (HF_HOME=/opt/cache in the image), which
solution.py searches at runtime. Models already shipped under assets/models are
not downloaded again. Uses only the standard library.
"""

import os
import shutil
import sys
import time
import urllib.request
from pathlib import Path

MODELS = [
    # (local name, repo, pinned commit, [(path, expected size)])
    (
        "snowflake-arctic-embed-m-v1.5",
        "Snowflake/snowflake-arctic-embed-m-v1.5",
        "e58a8f756156a1293d763f17e3aae643474e9b8a",
        [("onnx/model_int8.onnx", 110145162), ("tokenizer.json", 711649)],
    ),
    (
        "gte-reranker-modernbert-base",
        "Alibaba-NLP/gte-reranker-modernbert-base",
        "f7481e6055501a30fb19d090657df9ec1f79ab2c",
        [("onnx/model_int8.onnx", 150871837), ("tokenizer.json", 3583499)],
    ),
]
HOSTS = ["https://huggingface.co", "https://hf-mirror.com"]
HERE = Path(__file__).resolve().parent
DEST = Path(os.environ.get("HF_HOME", "/opt/cache")) / "models"


def _fetch(url: str, out: Path) -> None:
    tmp = out.with_suffix(out.suffix + ".part")
    req = urllib.request.Request(url, headers={"User-Agent": "dataquest-prefetch/1.0"})
    with urllib.request.urlopen(req, timeout=60) as r, open(tmp, "wb") as f:
        shutil.copyfileobj(r, f, length=1 << 20)
    tmp.replace(out)


def main() -> None:
    for name, repo, rev, files in MODELS:
        if all((HERE / "assets" / "models" / name / p).is_file() for p, _ in files):
            print(f"[prefetch] {name}: shipped in assets, skipping")
            continue
        for path, size in files:
            out = DEST / name / path
            out.parent.mkdir(parents=True, exist_ok=True)
            if out.is_file() and out.stat().st_size == size:
                continue
            ok = False
            for attempt in range(6):
                host = HOSTS[attempt % len(HOSTS)]
                url = f"{host}/{repo}/resolve/{rev}/{path}"
                try:
                    t0 = time.time()
                    _fetch(url, out)
                    if out.stat().st_size != size:
                        raise IOError(f"size {out.stat().st_size} != {size}")
                    print(f"[prefetch] {name}/{path} ({size >> 20} MiB) in {time.time() - t0:.0f}s from {host}")
                    ok = True
                    break
                except Exception as e:  # retry with backoff / other host
                    print(f"[prefetch] {url} failed: {e!r}", file=sys.stderr)
                    time.sleep(3 * (attempt + 1))
            if not ok:
                # Leave no partial model: solution.py then falls back to lexical retrieval.
                print(f"[prefetch] giving up on {name}/{path}", file=sys.stderr)
                shutil.rmtree(DEST / name, ignore_errors=True)
                break


if __name__ == "__main__":
    main()
